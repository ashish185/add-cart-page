import React from 'react';
import ReactDOM from 'react-dom';
import Main from './Containers/Main'; 
export default function index() {
    return (
        <div>
            HI
        </div>
    )
}
ReactDOM.render(<Main/>, document.getElementById('app'))