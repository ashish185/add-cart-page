# How to run
* Install the node modules using npm install.
* Run server using npm run start
# Tools and Library used
1. React as JavaScript library
 * To attain resuablity.
 * Faster performance.
2. SASS as a preprocessor
 * To avoid redudancy of CSS.
3. Webpack as a Bundler
 * For bundling and to create dependency grapth of all the files in project.
4. Babel
 * As a transpiler for ES6 syntax.
5. Editor: Visual Studio Code
## Scope of Imporovement
1. Proptypes could have be added.
2. Sting literals could have put in Constants.
### Lighthouse score
![LightScorePic](LightScorePic.JPGf)